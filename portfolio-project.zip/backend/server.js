
const express = require("express");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

app.post("/contact", (req, res) => {
  console.log(req.body);
  res.send("Message received");
});

app.listen(5000, () => console.log("Backend running on 5000"));
