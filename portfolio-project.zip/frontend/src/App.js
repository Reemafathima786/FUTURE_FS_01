
function App() {
  function sendData(e) {
    e.preventDefault();
    fetch("http://localhost:5000/contact", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name: document.getElementById("name").value,
        email: document.getElementById("email").value,
        message: document.getElementById("msg").value
      })
    });
    alert("Message Sent");
  }

  return (
    <div style={{ padding: "20px" }}>
      <h1>Reema Fathima</h1>
      <p>Java Full Stack Developer</p>

      <h2>Skills</h2>
      <ul>
        <li>Java</li>
        <li>React</li>
        <li>Node.js</li>
        <li>MongoDB</li>
      </ul>

      <h2>Contact Me</h2>
      <form onSubmit={sendData}>
        <input id="name" placeholder="Name" /><br /><br />
        <input id="email" placeholder="Email" /><br /><br />
        <textarea id="msg" placeholder="Message"></textarea><br /><br />
        <button>Send</button>
      </form>
    </div>
  );
}

export default App;
